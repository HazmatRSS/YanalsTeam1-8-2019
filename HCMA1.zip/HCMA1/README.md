# Hazardous Chemicals Management App - Android Internship/Developing graduation project 2 @ Princess Sumaya University & Royal Scietific Society 

### Description
A students' graduation project at Princess Sumaya University, the idea of the project was ubsracted from the Royal Scietific Society.

HCMA is an app for managing the Banned and Restricted statuses of the hazardous chemicals, along with the materials safety data sheets.


### How to install the app.
	1- Clone this repository into your machine.
    2- Unzip the folder.
    3- open app --> build --> outputs --> apk.
    4- copy the app into your android phone and run it while being connected to the RSS network*********.
    Have fun.
    
### NOTES:
	for me to accomplish the tasks of this project I've 
    taken the course at www.udemy.com and I've used the help 
    of the internet:
    (Github.com , stackoverflow.com, developers.Google.com)
     
    
##### *for further questions don't hesitate to contact me via email --> yanalotaibi@gmail.com 
yanal otaibi :) .	