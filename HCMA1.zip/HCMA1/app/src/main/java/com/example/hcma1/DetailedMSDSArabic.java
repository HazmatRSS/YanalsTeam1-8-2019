package com.example.hcma1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DetailedMSDSArabic extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_msdsarabic);

        //        String url = "";
//        String Ingredients = "http://172.27.2.119:8092/msdsclient/ProductIngredientsJSON?"; //ProductID=10920

        final Button exposureControls = findViewById(R.id.exposure_controls);
        Button productSynonyms = findViewById(R.id.product_synonyms);
        Button properties = findViewById(R.id.physical_chemical_properties);
        Button stability = findViewById(R.id.stability_reactivity);
        Button releaseAccident = findViewById(R.id.release_accident_measures);
        Button firstAid = findViewById(R.id.first_aid_measures);
        Button transportInfo = findViewById(R.id.transport_info);
        Button hazardsIdentification = findViewById(R.id.hazards_identification);
        Button disposal = findViewById(R.id.disposal_considerations);
        Button handling = findViewById(R.id.handling_storage);
        Button regulatory = findViewById(R.id.regulatory_info);
        Button firefighting = findViewById(R.id.firefighting_measures);
        Button toxi = findViewById(R.id.toxilogical_info);
        Button ingredients = findViewById(R.id.ingredients);
        Button moreDetails= findViewById(R.id.more_details);
        Button ecological = findViewById(R.id.ecological_info);


        Intent incomingData = getIntent();
        double v = 0;
        final double prdctid = incomingData.getDoubleExtra("productID", v);
        String productID = String.valueOf(prdctid);
        productID= productID.replace(".","");
        Integer productIDint = Integer.valueOf(productID);
        productIDint = productIDint/10;
        String productname = incomingData.getStringExtra("ProductName");
        String casno = incomingData.getStringExtra("CASNo");
        TextView chemnamemsds = findViewById(R.id.chemnamemsds);
        TextView casnomsds = findViewById(R.id.casnomsds);
        chemnamemsds.setText(productname);
        TextView manufacturer = findViewById(R.id.manu);
        String manu = incomingData.getStringExtra("manufacturer");
        manufacturer.setText(manu);

        Log.d("GTA", casno);

        if (casno.contains("null" ) || casno == null) {
            casnomsds.setText("N/A");
        }else{
            casnomsds.setText(casno);
        }
        Log.d("product id hahhahahahha", String.valueOf(productIDint));


        exposureControls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                //       buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "ExposureControls");
                startActivity(buttontodetail);
            }
        });

        productSynonyms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                //  buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "ProductSynonyms");
                startActivity(buttontodetail);
            }
        });

        properties.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "PhysicalAndChemicalProperties");
                startActivity(buttontodetail);
            }
        });

        stability.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "StabilityAndReactivity");
                startActivity(buttontodetail);
            }
        });

        releaseAccident.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "ReleaseAccidentMeasures");
                startActivity(buttontodetail);
            }
        });

        firstAid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "FirstAidMeasures");
                startActivity(buttontodetail);
            }
        });

        transportInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "TransportInformation");
                startActivity(buttontodetail);
            }
        });

        hazardsIdentification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "HazardsIdentification");
                startActivity(buttontodetail);
            }
        });

        disposal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "DisposalConsiderations");
                startActivity(buttontodetail);
            }
        });

        handling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "HandlingAndStorage");
                startActivity(buttontodetail);
            }
        });

        regulatory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "RegulatoryInformation");
                startActivity(buttontodetail);
            }
        });

        ecological.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "EcologicalInformation");
                startActivity(buttontodetail);
            }
        });

        firefighting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "FireFightingMeasures");
                startActivity(buttontodetail);
            }
        });

        toxi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "ToxicologicalInformation");
                startActivity(buttontodetail);
            }
        });

        ingredients.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "Ingredients");
                startActivity(buttontodetail);
            }
        });

        moreDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent buttontodetail = new Intent(view.getContext(), buttonToDetailsMsdsArabic.class);
                buttontodetail.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                buttontodetail.putExtra("productID", prdctid);
                buttontodetail.putExtra("detail", "OtherInformation");
                startActivity(buttontodetail);
            }
        });


    }
    }

