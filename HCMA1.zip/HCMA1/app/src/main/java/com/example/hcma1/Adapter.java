package com.example.hcma1;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<List_Item> listItems;
    private Context context;

    public Adapter(List<List_Item> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_card_view,parent,false);
        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {
        final List_Item list = listItems.get(position);

        holder.textViewchemicalname.setText(list.getChemicalName());
        holder.textViewhscode.setText(list.getHSCode());
        Log.d("hiiii", String.valueOf(list.getStatus()));

        //--------------------------coloring cards-------------------------------
        if (list.getStatus() == 1) {
            holder.clickedCard.setBackground(context.getDrawable(R.color.restricted));
        }
        if (list.getStatus() == 2) {
            holder.clickedCard.setBackground(context.getDrawable(R.color.banned));
        }
        if (list.getStatus() == 3) {
            holder.clickedCard.setBackground(context.getDrawable(R.color.both));
        }
        //--------------------------end of coloring cards-------------------------





        holder.clickedCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //TODO: open the new intent with the detailed info about the chemical
                Toast.makeText(context, "You Clicked --> " + list.getChemicalName(),Toast.LENGTH_SHORT).show();
                Intent detailedIntent = new Intent(view.getContext(), DetailedBREnglish.class);
                detailedIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                detailedIntent.putExtra("MaterialID", list.getMaterialID());
                context.startActivity(detailedIntent);
            }
        });



    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder{

        public TextView textViewchemicalname; //textview head
        public TextView textViewhscode; // textviewdesc
        public LinearLayout clickedCard;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewchemicalname = itemView.findViewById(R.id.Chemical_Name);
            textViewhscode = itemView.findViewById(R.id.HS_Code);
            clickedCard = itemView.findViewById(R.id.clickedCard);


        }
        }
    }
