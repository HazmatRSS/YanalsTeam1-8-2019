package com.example.hcma1;

public class List_Item {
    private Double MaterialID;
    private String ChemicalName;
    private String HSCode;
    private String MaterialSynonyms;
    private int Status;

    public List_Item(Double materialID, String chemicalName, String HSCode, String MaterialSynonyms, int Status) {
        MaterialID = materialID;
        ChemicalName = chemicalName;
        this.HSCode = HSCode;
        this.MaterialSynonyms = MaterialSynonyms;
        this.Status = Status;
    }

    public void setMaterialID(Double materialID) {
        MaterialID = materialID;
    }

    public void setChemicalName(String chemicalName) {
        ChemicalName = chemicalName;
    }

    public void setHSCode(String HSCode) {
        this.HSCode = HSCode;
    }

    public void setMaterialSynonyms(String MaterialSynonyms) {
        this.MaterialSynonyms = MaterialSynonyms;
    }

    public void setStatus(int Status) {
        this.Status = Status;
    }

    public Double getMaterialID() {
        return MaterialID;
    }

    public String getChemicalName() {
        return ChemicalName;
    }

    public String getHSCode() {
        return HSCode;
    }

    public String getMaterialSynonyms() {
        return MaterialSynonyms;
    }

    public int getStatus() {
        return Status;
    }
}
