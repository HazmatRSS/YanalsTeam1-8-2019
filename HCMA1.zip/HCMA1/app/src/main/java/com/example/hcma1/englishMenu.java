package com.example.hcma1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class englishMenu extends AppCompatActivity {


    Button BR_english = null;
    Button MSDS_english = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english_menu);

        ImageView BRinfo = findViewById(R.id.info1);

        BRinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(englishMenu.this,Pop.class));
            }
        });


        BR_english = findViewById(R.id.englishBR);
        MSDS_english = findViewById(R.id.englishMSDS);

        BR_english.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent A = new Intent(view.getContext(), BR_english.class);
                startActivity(A);
            }
        });

        MSDS_english.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent B = new Intent(view.getContext(), MSDS_english.class);
                startActivity(B);
            }
        });
    }
}
