package com.example.hcma1;

public class list_item_msds {

    private Double ProductID;
    private String ProductName;
    private String CasNo;
    private String ManufacturingFacility;
    private String ProductIngredients;
    //  private String IngredientProductName;
    //  private String IngredientCASNo;


    public list_item_msds(Double productID, String productName, String casNo, String manufacturingFacility, String productIngredients) {
        ProductID = productID;
        ProductName = productName;
        CasNo = casNo;
        ManufacturingFacility = manufacturingFacility;
        ProductIngredients = productIngredients;
    }

    public Double getProductID() {
        return ProductID;
    }

    public String getProductName() {
        return ProductName;
    }

    public String getCasNo() {
        return CasNo;
    }

    public String getManufacturingFacility() {
        return ManufacturingFacility;
    }

    public String getProductIngredients() {
        return ProductIngredients;
    }

    public void setProductID(Double productID) {
        ProductID = productID;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }

    public void setCasNo(String casNo) {
        CasNo = casNo;
    }

    public void setManufacturingFacility(String manufacturingFacility) {
        ManufacturingFacility = manufacturingFacility;
    }

    public void setProductIngredients(String productIngredients) {
        ProductIngredients = productIngredients;
    }
}
