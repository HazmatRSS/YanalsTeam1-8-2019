package com.example.hcma1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BR_arabic extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{


    ArrayAdapter<CharSequence> adapter= null;
    private RequestQueue mQueue;
    //Recycler view + Volley
    public static int page = 0;
    public static int id = 0;
    public String BASE_URL = "http://172.27.2.119:8092/bRMaterials/SearchBRMJSON?page=0";
    public String url = "http://172.27.2.119:8092/bRMaterials/SearchBRMJSON?page=0";
    private String orgJSON = "http://172.27.2.119:8092/BRMaterials/BRMOrganizations";
    private RecyclerView recyclerView;
    private RecyclerView.Adapter recyclerViewAdapter;
    private List<List_Item> listItemList;
    //Recycler view + Volley

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_br_arabic);

        final EditText chemicalname = findViewById(R.id.Chemical_name_arabicay);
        final EditText hscode = findViewById(R.id.yanal);
        final RadioGroup radioGroup = findViewById(R.id.RadioG_arabic);
        //cardView = findViewById(R.id.cardview);

        //fetching organizations

        fetchOrganizations();
        //end of fetching organizations

        //Recycler view + Volley
        recyclerView = findViewById(R.id.RecyclerV_arabic);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Button button_parse = findViewById(R.id.Search_MDSD_Arabic);
        listItemList = new ArrayList<>();

        recyclerViewAdapter = new Adapter_Arabic(listItemList, getApplicationContext());
        recyclerView.setAdapter(recyclerViewAdapter);

        mQueue = Volley.newRequestQueue(this);

        button_parse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clear();
                url = BASE_URL;
                String name = chemicalname.getText().toString();
                String code = hscode.getText().toString();
                int selectedRadioButton = radioGroup.getCheckedRadioButtonId();

                url = url + "&";
                if (name != null || name != "" || name!=" ") {
                    url = url + "ChemicalName=" + name;
                }
                url = url + "&";
                if (code != null || code != "" || code!=" "){
                    url = url + "HSCode=" + code;
                }


                if (selectedRadioButton == R.id.radio_restricted_arabic){
                    Log.d("frfr","frfr");
                    url = url + "&";
                    url = url + "SubstanceStatus=" + "1";
                }else if (selectedRadioButton == R.id.radio_banned_arabic){
                    url = url + "&";
                    url = url + "SubstanceStatus=" + "2";
                }else if (selectedRadioButton == R.id.radio_both_arabic) {
                    url = url + "&";
                    url = url + "SubstanceStatus=" + "3";
                }

                if (id != 0){
                    url = url + "&";
                    url = url + "organization=" + id;
                }


                Log.d("the URL is: ", url);
                jsonParse();
            }
        });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (!recyclerView.canScrollVertically(1)) {

//                    recyclerView.scrollToPosition(listItemList.size() - 1);
                    int StartIndex = url.indexOf("page");
                    int endIndex = url.indexOf("&");
                    Log.d("StartIndex", String.valueOf(StartIndex));
                    Log.d("endIndex", String.valueOf(endIndex));
                    page++;
                    url = url.substring(0,StartIndex) + "page=" + page + url.substring(endIndex);
                    Log.d("hahahahjajajajja", url);
                    jsonParse();
                }
            }
        });

    }

    public void fetchOrganizations(){

        StringRequest stringRequest = new StringRequest(Request.Method.GET, orgJSON,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            final ArrayList<String> arrayListOfOrgs= new ArrayList<>();
                            final ArrayList<String> arrayListOfOrgsid= new ArrayList<>();
                            JSONObject jsonObject = new JSONObject(response);
                            //Organizations
                            JSONObject organizations = jsonObject.getJSONObject("ProductList");
                            JSONArray jsonArray = organizations.getJSONArray("Organizations");

                            arrayListOfOrgs.add("--اختر الهيئة المعنية--");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject o = jsonArray.getJSONObject(i);
                                String orgNameseng = o.getString("OrganizationDesc_ar");
                                int orgID = o.getInt("OrganizationId");
                                Log.d("mo77", String.valueOf(orgID));
                                Log.d("aburumman", orgNameseng);
                                arrayListOfOrgs.add(orgNameseng);
                            }

                            //spinner
                            Spinner spinner = findViewById(R.id.GovSpinnerAr);
                            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(BR_arabic.this, android.R.layout.simple_spinner_item, arrayListOfOrgs);
                            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            spinner.setAdapter(arrayAdapter);
                            spinner.setOnItemSelectedListener(BR_arabic.this);
                            //end of spinner

                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }

    //START JSON PARSE FUNCTION
    private void jsonParse() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("يرجى الإنتظار...");
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("ProductList");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject o = jsonArray.getJSONObject(i);
                                List_Item item = new List_Item(
                                        o.getDouble("MaterialID"),
                                        o.getString("ChemicalName"),
                                        o.getString("HSCode"),
                                        o.getString("MaterialSynonyms"),
                                        o.getInt("Status")
                                );
                                listItemList.add(item);
                                recyclerViewAdapter.notifyDataSetChanged();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        Log.d("the last id is: ", String.valueOf(id));
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void clear() {


        int size = listItemList.size();
        if (size > 0) {
            for (int i = 0; i < size; i++) {
                listItemList.remove(0);
            }
            recyclerViewAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        String text = adapterView.getItemAtPosition(i).toString();
        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
        getOrgId(text);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        id = 0;
    }


    public void getOrgId(final String t) {

        StringRequest stringRequest = new StringRequest(Request.Method.GET, orgJSON,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try{
                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject organizations = jsonObject.getJSONObject("ProductList");
                            JSONArray jsonArray = organizations.getJSONArray("Organizations");

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject o = jsonArray.getJSONObject(i);

                                if (t.contains("--اختر الهيئة المعنية--")){
                                    id=0;
                                    break;
                                }else if (o.getString("OrganizationDesc_ar").contains(t)){
                                    id = o.getInt("OrganizationId");
                                    Log.d("the id is:", String.valueOf(id));
                                }

                            }


                        }catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}


