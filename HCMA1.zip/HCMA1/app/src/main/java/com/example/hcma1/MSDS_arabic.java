package com.example.hcma1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MSDS_arabic extends AppCompatActivity {


    private static final int MY_SOCKET_TIMEOUT_MS = 50000;
    TextView Showmore_arabic, Showless_arabic;
    EditText ProductNameEnglish_arabic,CASNo_MSDS_English_arabic,IngredientProductNameEnglish_arabic;
    EditText Ingredient_CAS_No_arabic, manufacturer_arabic;


    private RequestQueue mQueue;
    private CardView cardviewMSDS;

    //Recycler view + Volley
    private String BASE_URL = "http://172.27.2.119:8092/msdsclient/SearchProductsJSON?page=0";
    private String url = "http://172.27.2.119:8092/msdsclient/SearchProductsJSON?page=0";
    private static int page = 0;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter recyclerViewAdapter;
    private List<list_item_msds> listMSDS;
    //Recycler view + Volley

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msds_arabic);


        manufacturer_arabic = findViewById(R.id.manufacturer_arabic);
        Showmore_arabic = findViewById(R.id.Showmore_MSDS_arabic);
        Showless_arabic = findViewById(R.id.Showless_MSDS_arabic);
        ProductNameEnglish_arabic = findViewById(R.id.ProductNameEnglish_arabic);
        CASNo_MSDS_English_arabic = findViewById(R.id.CASNo_MSDS_English_arabic);
        IngredientProductNameEnglish_arabic = findViewById(R.id.IngredientProductNameEnglish_arabic);
        Ingredient_CAS_No_arabic = findViewById(R.id.Ingredient_CAS_No_arabic);
        cardviewMSDS = findViewById(R.id.cardviewMSDS);




        //Recycler view + Volley
        recyclerView = findViewById(R.id.RecyclerV_MSDS_Arabic);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Button button_parse = findViewById(R.id.Search_MSDS_Arabic);
        listMSDS = new ArrayList<>();
        mQueue = Volley.newRequestQueue(this);


        button_parse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clear();
                url = BASE_URL;
                String name = ProductNameEnglish_arabic.getText().toString();
                String manufacturer = manufacturer_arabic.getText().toString();
                String casno = CASNo_MSDS_English_arabic.getText().toString();
                String ingproductname = IngredientProductNameEnglish_arabic.getText().toString();
                String ingCASno = Ingredient_CAS_No_arabic.getText().toString();

                url = url + "&";
                if (name != null || name != "" || name!=" ") {
                    url = url + "ProductNameEnglish=" + name;
                }
                url = url + "&";
                if (manufacturer != null || manufacturer != "" || manufacturer!=" "){
                    url = url + "ManufacturingFacility=" + manufacturer;
                }
                url = url + "&";
                if (casno != null || casno != "" || casno!=" "){
                    url = url + "CASNo=" + casno;
                }
                url = url + "&";
                if (ingproductname != null || ingproductname != "" || ingproductname!=" "){
                    url = url + "IngredientProductNameEnglish=" + ingproductname;
                }
                url = url + "&";
                if (ingCASno != null || ingCASno != "" || ingCASno!=" "){
                    url = url + "IngredientCASNo=" + ingCASno;
                }


                Log.d("the URL is: ", url);
                jsonParse();

            }
        });


        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (!recyclerView.canScrollVertically(1)) {
                    int StartIndex = url.indexOf("page");
                    Log.d("StartIndex", String.valueOf(StartIndex));
                    int endIndex = url.indexOf("&");
                    Log.d("endIndex", String.valueOf(endIndex));
                    page++;

                    url = url.substring(0,StartIndex) + "page=" + page + url.substring(endIndex);
                    Log.d("hahahahjajajajja", url);
                    jsonParse();

                }
            }
        });


    }


    //START JSON PARSE FUNCTION
    private void jsonParse() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("يرجى الإنتظار...");
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("ProductList");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject o = jsonArray.getJSONObject(i);
                                list_item_msds item = new list_item_msds(
                                        o.getDouble("ProductID"),
                                        o.getString("ProductName"),
                                        o.getString("CasNo"),
                                        o.getString("ManufacturingFacility"),
                                        o.getString("ProductIngredients")

                                );
                                listMSDS.add(item);
                            }

                            recyclerViewAdapter = new Adapter_MSDS_Arabic(listMSDS , getApplicationContext());
                            recyclerView.setAdapter(recyclerViewAdapter);
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }



    public void ShowmoreF_MSDS_arabic(View v4){
        IngredientProductNameEnglish_arabic.setVisibility(View.VISIBLE);
        Ingredient_CAS_No_arabic.setVisibility(View.VISIBLE);
        Showmore_arabic.setVisibility(View.GONE);
        Showless_arabic.setVisibility(View.VISIBLE);
        manufacturer_arabic.setVisibility(View.VISIBLE);
    }

    public void ShowlessF_MSDS_arabic(View v5){
        IngredientProductNameEnglish_arabic.setVisibility(View.GONE);
        Ingredient_CAS_No_arabic.setVisibility(View.GONE);
        Showmore_arabic.setVisibility(View.VISIBLE);
        Showless_arabic.setVisibility(View.GONE);
        manufacturer_arabic.setVisibility(View.GONE);
    }


    public void clear() {


        int size = listMSDS.size();
        if (size > 0) {
            for (int i = 0; i < size; i++) {
                listMSDS.remove(0);
            }
            recyclerViewAdapter.notifyDataSetChanged();
        }
    }
}
