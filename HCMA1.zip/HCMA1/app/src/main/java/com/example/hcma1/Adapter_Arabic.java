package com.example.hcma1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter_Arabic extends RecyclerView.Adapter<Adapter_Arabic.ViewHolder> {
    private List<List_Item> listItems;
    private Context context;

    public Adapter_Arabic(List<List_Item> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_card_view_arabic,parent,false);
        return new Adapter_Arabic.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final List_Item list = listItems.get(position);

        holder.textViewchemicalname.setText(list.getChemicalName());
        holder.textViewhscode.setText(list.getHSCode());

        //--------------------------coloring cards-------------------------------
        if (list.getStatus() == 1) {
            holder.clickedCardArabic.setBackground(context.getDrawable(R.color.restricted));
        }
        if (list.getStatus() == 2) {
            holder.clickedCardArabic.setBackground(context.getDrawable(R.color.banned));
        }
        if (list.getStatus() == 3) {
            holder.clickedCardArabic.setBackground(context.getDrawable(R.color.both));
        }
        //--------------------------end of coloring cards-------------------------





        holder.clickedCardArabic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //TODO: open the new intent with the detailed info about the chemical
                Toast.makeText(context, "You Clicked --> " + list.getChemicalName(),Toast.LENGTH_SHORT).show();
                Intent detailedIntent = new Intent(view.getContext(), DetailedBRArabic.class);
                detailedIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                detailedIntent.putExtra("MaterialID", list.getMaterialID());
                context.startActivity(detailedIntent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        public TextView textViewchemicalname; //textview head
        public TextView textViewhscode; // textviewdesc
        public LinearLayout clickedCardArabic;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewchemicalname = itemView.findViewById(R.id.Chemical_Nameary);
            textViewhscode = itemView.findViewById(R.id.HS_Codeary);
            clickedCardArabic = itemView.findViewById(R.id.clickedCard_arabic);

        }
    }
}
