package com.example.hcma1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class arabicMenu extends AppCompatActivity {


    Button BR_arabic = null;
    Button MSDS_arabic = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arabic_menu);

        BR_arabic = findViewById(R.id.arabicBR);
        MSDS_arabic = findViewById(R.id.arabicMSDS);

        BR_arabic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent C = new Intent(view.getContext(), BR_arabic.class);
                startActivity(C);
            }
        });

        MSDS_arabic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent D = new Intent(view.getContext(), MSDS_arabic.class);
                startActivity(D);
            }
        });

    }
}
