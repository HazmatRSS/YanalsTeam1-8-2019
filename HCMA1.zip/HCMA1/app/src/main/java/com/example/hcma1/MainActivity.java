package com.example.hcma1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button toEnglish = null;
    Button toArabic = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toEnglish = findViewById(R.id.toEnglish);
        toArabic = findViewById(R.id.toArabic);

        toEnglish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent E = new Intent(view.getContext(), englishMenu.class);
                startActivity(E);
            }
        });

        toArabic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent A = new Intent(view.getContext(), arabicMenu.class);
                startActivity(A);
            }
        });


    }
}
