package com.example.hcma1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;

public class DetailedBREnglish extends AppCompatActivity {

    private String url = "http://172.27.2.119:8092/bRMaterials/BRMDetailsJSON?"; //materialId=3551
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_brenglish);

        final Button detailsbutton = findViewById(R.id.DetailsButton);
        final Button statusbutton = findViewById(R.id.StatusButton);
        final LinearLayout one = findViewById(R.id.one);
        final LinearLayout two = findViewById(R.id.two);
        final LinearLayout three = findViewById(R.id.three);
        final LinearLayout four = findViewById(R.id.four);
        final LinearLayout five = findViewById(R.id.five);
        final LinearLayout six = findViewById(R.id.six);
        final LinearLayout seven = findViewById(R.id.seven);
        final LinearLayout eight = findViewById(R.id.eight);
        final LinearLayout nine = findViewById(R.id.nine);

        final LinearLayout sone = findViewById(R.id.sone);
        final LinearLayout stwo = findViewById(R.id.stwo);
        final LinearLayout sthree = findViewById(R.id.sthree);
        final LinearLayout sfour = findViewById(R.id.sfour);
        final LinearLayout sfive = findViewById(R.id.sfive);
        final LinearLayout ssix = findViewById(R.id.ssix);
        final LinearLayout sseven = findViewById(R.id.sseven);
        final LinearLayout seight = findViewById(R.id.seight);
        final LinearLayout snine = findViewById(R.id.snine);


        detailsbutton.setOnClickListener(new View.OnClickListener() {
            boolean showingFirst = true;
            @Override
            public void onClick(View view) {

                if(showingFirst == true){
                    one.setVisibility(View.VISIBLE);
                    two.setVisibility(View.VISIBLE);
                    three.setVisibility(View.VISIBLE);
                    four.setVisibility(View.VISIBLE);
                    five.setVisibility(View.VISIBLE);
                    six.setVisibility(View.VISIBLE);
                    seven.setVisibility(View.VISIBLE);
                    eight.setVisibility(View.VISIBLE);
                    nine.setVisibility(View.VISIBLE);
                    detailsbutton.setText("  Chemical Details: ➖");
                    showingFirst = false;
                }else{
                    one.setVisibility(View.GONE);
                    two.setVisibility(View.GONE);
                    three.setVisibility(View.GONE);
                    four.setVisibility(View.GONE);
                    five.setVisibility(View.GONE);
                    six.setVisibility(View.GONE);
                    seven.setVisibility(View.GONE);
                    eight.setVisibility(View.GONE);
                    nine.setVisibility(View.GONE);
                    detailsbutton.setText("  Chemical Details: ➕");
                    showingFirst = true;
                }

            }
        });

        statusbutton.setOnClickListener(new View.OnClickListener() {
            boolean showingFirst = true;
            @Override
            public void onClick(View view) {

                if(showingFirst == true){
                    sone.setVisibility(View.VISIBLE);
                    stwo.setVisibility(View.VISIBLE);
                    sthree.setVisibility(View.VISIBLE);
                    sfour.setVisibility(View.VISIBLE);
                    sfive.setVisibility(View.VISIBLE);
                    ssix.setVisibility(View.VISIBLE);
                    sseven.setVisibility(View.VISIBLE);
                    seight.setVisibility(View.VISIBLE);
                    snine.setVisibility(View.VISIBLE);
                    statusbutton.setText("  Chemical Status: ➖");
                    showingFirst = false;
                }else{
                    sone.setVisibility(View.GONE);
                    stwo.setVisibility(View.GONE);
                    sthree.setVisibility(View.GONE);
                    sfour.setVisibility(View.GONE);
                    sfive.setVisibility(View.GONE);
                    ssix.setVisibility(View.GONE);
                    sseven.setVisibility(View.GONE);
                    seight.setVisibility(View.GONE);
                    snine.setVisibility(View.GONE);
                    statusbutton.setText("  Chemical Status: ➕");
                    showingFirst = true;
                }

            }
        });



        Intent incomingData = getIntent();
        double v = 0;
        double matID = incomingData.getDoubleExtra("MaterialID", v);
        String matIDstring = String.valueOf(matID);
        matIDstring= matIDstring.replace(".","");
        Integer matidInteger = Integer.valueOf(matIDstring);
        matidInteger = matidInteger/10;
        //chemnamedetailed.setText(String.valueOf(matID));
        if (matID != 0.0){
            url = url + "materialId=" + matidInteger;
            Log.d("the url is =", url);
        }

        jsonParse();
    }

    private void jsonParse(){

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("fuckkk", url);
                        //Details
                        TextView chemnamedetailed = findViewById(R.id.chemnamedetailed);
                        TextView chemnamearabic = findViewById(R.id.chemnamearabic);
                        TextView casno = findViewById(R.id.casno);
                        TextView unno = findViewById(R.id.unno);
                        TextView hscode = findViewById(R.id.hscode);
                        TextView substancecat = findViewById(R.id.substancecat);
                        TextView org = findViewById(R.id.org);
                        TextView remarks = findViewById(R.id.remarks);
                        TextView synonyms = findViewById(R.id.synonyms);

                        //Status
                        TextView Pesticidesorg = findViewById(R.id.Pesticidesorg);
                        TextView Precursorsorg = findViewById(R.id.Precursorsorg);
                        TextView Explosivesorg = findViewById(R.id.Explosivesorg);
                        TextView Weaponsorg = findViewById(R.id.Weaponsorg);
                        TextView FANRorg = findViewById(R.id.FANRorg);
                        TextView Ozoneorg = findViewById(R.id.Ozoneorg);
                        TextView Industrialorg = findViewById(R.id.Industrialorg);
                        TextView Fertilizersorg = findViewById(R.id.Fertilizersorg);
                        TextView Chemicalsorg = findViewById(R.id.Chemicalsorg);
                        TextView Pesticides = findViewById(R.id.Pesticides);
                        TextView Precursors = findViewById(R.id.Precursors);
                        TextView Explosives = findViewById(R.id.Explosives);
                        TextView Weapons = findViewById(R.id.Weapons);
                        TextView FANR = findViewById(R.id.FANR);
                        TextView Ozone = findViewById(R.id.Ozone);
                        TextView Industrial = findViewById(R.id.Industrial);
                        TextView Fertilizers = findViewById(R.id.Fertilizers);
                        TextView Chemicals = findViewById(R.id.Chemicals);

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject ProductList = jsonObject.getJSONObject("ProductList");
                            chemnamedetailed.setText(ProductList.getString("ChemicalNameEn"));
                            if (ProductList.getString("ChemicalNameAr") != "null"){
                                chemnamearabic.setText(ProductList.getString("ChemicalNameAr"));
                            }else {
                                chemnamearabic.setText("--");
                            }
                            if (!ProductList.getString("CASNo").contains("null") ){
                                casno.setText(ProductList.getString("CASNo"));
                            }else {
                                casno.setText("--");
                            }
                            if (ProductList.getString("UnNo") != "null" || ProductList.getString("UnNo") != null){
                                unno.setText(ProductList.getString("UnNo"));
                            }else {
                                unno.setText("--");
                            }
                            hscode.setText(ProductList.getString("HSCode"));
                            if (ProductList.getString("SubstanceCategory") != "null" || ProductList.getString("SubstanceCategory") != null){
                                substancecat.setText(ProductList.getString("SubstanceCategory"));
                            }else {
                                substancecat.setText("--");
                            }
                            if (ProductList.getString("Organization") != "null" || ProductList.getString("Organization") != null){
                                org.setText(ProductList.getString("Organization"));
                            }else {
                                org.setText("--");
                            }
                            if (ProductList.getString("Remarks") != "null" || ProductList.getString("Remarks") != null){
                                remarks.setText(ProductList.getString("Remarks"));
                            }else {
                                remarks.setText("--");
                            }
                            synonyms.setText(ProductList.getString("MaterialSynonyms"));

                            //status

                            JSONArray SubstanceStatus = ProductList.getJSONArray("SubstanceStatus");
                            JSONObject SubstanceStatusObject = SubstanceStatus.getJSONObject(0);

                            Pesticidesorg.setText(SubstanceStatus.getJSONObject(0).getString("Organization") + "    :");
                            Pesticides.setText(SubstanceStatus.getJSONObject(0).getString("Status"));

                            Precursorsorg.setText(SubstanceStatus.getJSONObject(1).getString("Organization") + "    :");
                            Precursors.setText(SubstanceStatus.getJSONObject(1).getString("Status"));

                            Explosivesorg.setText(SubstanceStatus.getJSONObject(2).getString("Organization") + "    :");
                            Explosives.setText(SubstanceStatus.getJSONObject(2).getString("Status"));

                            Weaponsorg.setText(SubstanceStatus.getJSONObject(3).getString("Organization") + "    :");
                            Weapons.setText(SubstanceStatus.getJSONObject(3).getString("Status"));

                            FANRorg.setText(SubstanceStatus.getJSONObject(4).getString("Organization") + "    :");
                            FANR.setText(SubstanceStatus.getJSONObject(4).getString("Status"));

                            Ozoneorg.setText(SubstanceStatus.getJSONObject(5).getString("Organization") + "    :");
                            Ozone.setText(SubstanceStatus.getJSONObject(5).getString("Status"));

                            Industrialorg.setText(SubstanceStatus.getJSONObject(6).getString("Organization") + "    :");
                            Industrial.setText(SubstanceStatus.getJSONObject(6).getString("Status"));

                            Fertilizersorg.setText(SubstanceStatus.getJSONObject(7).getString("Organization") + "    :");
                            Fertilizers.setText(SubstanceStatus.getJSONObject(7).getString("Status"));

                            Chemicalsorg.setText(SubstanceStatus.getJSONObject(8).getString("Organization") + "    :");
                            Chemicals.setText(SubstanceStatus.getJSONObject(8).getString("Status"));

                            Log.d("corn", String.valueOf(SubstanceStatusObject));
                            Log.d("jaajajjajajajajjajaja", (SubstanceStatusObject.getString("Organization")));
                            JSONArray MaterialSynonymsArray = ProductList.getJSONArray("MaterialSynonyms");
                            Log.d("yanal is having sex", String.valueOf(MaterialSynonymsArray));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }



}
