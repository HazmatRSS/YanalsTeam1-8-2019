package com.example.hcma1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter_MSDS_Arabic extends RecyclerView.Adapter<Adapter_MSDS_Arabic.ViewHolder> {
    private List<list_item_msds> listItem;
    private Context context;

    public Adapter_MSDS_Arabic(List<list_item_msds> listItem, Context context) {
        this.listItem = listItem;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_card_msds_arabic,parent,false);
        return new Adapter_MSDS_Arabic.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final list_item_msds list_item_msds = listItem.get(position);

        if (holder.Product_name != null){

            holder.Product_name.setText(list_item_msds.getProductName());

        }

        if (holder.Manufacturer != null){
            holder.Manufacturer.setText(list_item_msds.getManufacturingFacility());
        }


        holder.clickedCardMSDS_Arabic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "You Clicked --> " + list_item_msds.getProductName(),Toast.LENGTH_SHORT).show();
                Intent detailedIntentmsds = new Intent(view.getContext(), DetailedMSDSArabic.class);
                detailedIntentmsds.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                detailedIntentmsds.putExtra("productID", list_item_msds.getProductID());
                detailedIntentmsds.putExtra("ProductName", list_item_msds.getProductName());
                detailedIntentmsds.putExtra("CASNo", list_item_msds.getCasNo());
                detailedIntentmsds.putExtra("manufacturer", list_item_msds.getManufacturingFacility());
                context.startActivity(detailedIntentmsds);
            }
        });


    }

    @Override
    public int getItemCount() {
        return listItem.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView Product_name; //textview head
        public TextView Manufacturer; // textviewdesc
        public LinearLayout clickedCardMSDS_Arabic;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            Product_name = itemView.findViewById(R.id.Product_name);
            Manufacturer = itemView.findViewById(R.id.Manufacturer);
            clickedCardMSDS_Arabic = itemView.findViewById(R.id.clickedCardMSDS_Arabic);


        }
    }
}
