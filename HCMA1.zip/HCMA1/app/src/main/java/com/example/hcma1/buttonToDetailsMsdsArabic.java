package com.example.hcma1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class buttonToDetailsMsdsArabic extends AppCompatActivity {

    String url = "http://172.27.2.119:8092/msdsclient/ProductDetailsJSON?";
    String IngredientsURL = "http://172.27.2.119:8092/msdsclient/ProductIngredientsJSON?"; //ProductID=1
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button_to_details_msds_arabic);

        Intent incomingData = getIntent();
        double v = 0;
        final double prdctid = incomingData.getDoubleExtra("productID", v);
        String productID = String.valueOf(prdctid);
        productID= productID.replace(".","");
        Integer productIDint = Integer.valueOf(productID);
        String detail = incomingData.getStringExtra("detail");


        Log.d("life is unfair", String.valueOf(productIDint));
        Log.d("LIFE IS HARD", detail);

        TextView pdetail = findViewById(R.id.pdetail);

        pdetail.setText(detail);

        url = url + "ProductId=" + productIDint/10;
        IngredientsURL = IngredientsURL + "ProductId=" + productIDint/10;
        Log.d("hiiii mother fucker", url);

        if (detail.contains("Ingredients")){
            jsonParseIngredients();
        }else {
            jsonParse(detail);
        }

    }

    private void jsonParse(final String detail){

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        TextView pname = findViewById(R.id.pname);
                        TextView blankarea = findViewById(R.id.blankarea);

                        try{
                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject ProductList = jsonObject.getJSONObject("ProductList");
                            pname.setText(ProductList.getString("ProductName"));
                            blankarea.setText(ProductList.getString(detail));


                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void jsonParseIngredients(){

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                IngredientsURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        TextView pname = findViewById(R.id.pname);
                        TextView blankarea = findViewById(R.id.blankarea);
                        TextView title = findViewById(R.id.titleee);
                        title.setText("Ingredient CAS-NO");
                        TextView title1 = findViewById(R.id.pdetail);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject ProductList = jsonObject.getJSONObject("ProductList");
                            pname.setText(ProductList.getString("ProductName"));
                            title.setText("Ingredient CASNo");
                            blankarea.setText("IngredientProductName: \n \n \t" + ProductList.getString("IngredientProductName"));
                            title1.setText(ProductList.getString("IngredientCASNo"));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}

