package com.example.hcma1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter_MSDS  extends RecyclerView.Adapter<Adapter_MSDS.ViewHolder> { //add the extention


    private List<list_item_msds> listItem;
    private Context context;


    public Adapter_MSDS(List<list_item_msds> listItem, Context context) {
        this.listItem = listItem;
        this.context = context;
    }

    @NonNull
    @Override
    public Adapter_MSDS.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_card_msds,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter_MSDS.ViewHolder holder, int position) {

        final list_item_msds list_item_msds = listItem.get(position);

        if (holder.Product_name != null){

        holder.Product_name.setText(list_item_msds.getProductName());

        }

        if (holder.Manufacturer != null){
        holder.Manufacturer.setText(list_item_msds.getManufacturingFacility());
        }


        holder.clickedCardMSDS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "You Clicked --> " + list_item_msds.getProductName(),Toast.LENGTH_SHORT).show();
                Intent detailedIntentmsds = new Intent(view.getContext(), DetailedMSDSEng.class);
                detailedIntentmsds.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                detailedIntentmsds.putExtra("productID", list_item_msds.getProductID());
                detailedIntentmsds.putExtra("ProductName", list_item_msds.getProductName());
                detailedIntentmsds.putExtra("CASNo", list_item_msds.getCasNo());
                detailedIntentmsds.putExtra("manufacturer", list_item_msds.getManufacturingFacility());
                context.startActivity(detailedIntentmsds);
            }
        });

    }

    @Override
    public int getItemCount() {
        return listItem.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView Product_name; //textview head
        public TextView Manufacturer; // textviewdesc
        public LinearLayout clickedCardMSDS;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            Product_name = itemView.findViewById(R.id.Product_name);
            Manufacturer = itemView.findViewById(R.id.Manufacturer);
            clickedCardMSDS = itemView.findViewById(R.id.clickedCardMSDS);


    }
}
}

//clickedCardMSDS